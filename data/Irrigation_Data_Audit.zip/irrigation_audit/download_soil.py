"""Download small SLGA AWC v2 subsets at station coordinates for access screening.
These are station-area samples, not selected agricultural field parameters.
"""
from pathlib import Path
import urllib.request,urllib.parse,concurrent.futures,json
ROOT=Path(__file__).resolve().parent
sites={'kyabram':(-36.335,145.0638),'kununurra_aero':(-15.781,128.710)}
def get(task):
 site,lat,lon,depth=task
 params=[('service','WCS'),('version','2.0.1'),('request','GetCoverage'),('coverageId','slga__awc_ev_n_p_au_trn_n_20210614'),('format','image/tiff'),('subset',f'Lat({lat-0.001},{lat+0.001})'),('subset',f'Long({lon-0.001},{lon+0.001})'),('subset',f'DEPTH("{depth}")')]
 url='https://geoserver.tern.org.au/geoserver/slga/AWC_v2/ows?'+urllib.parse.urlencode(params)
 result=dict(site=site,latitude=lat,longitude=lon,depth=depth,url=url)
 try:
  with urllib.request.urlopen(url,timeout=45) as r:d=r.read();ct=r.headers.get('Content-Type')
  fn=f'{site}_awc_{depth}.tif';(ROOT/'raw'/fn).write_bytes(d)
  result.update(file='raw/'+fn,bytes=len(d),content_type=ct,status='downloaded' if d[:2] in [b'II',b'MM'] else 'unexpected_response')
  if result['status']!='downloaded': result['response']=d[:500].decode(errors='replace')
 except Exception as e:result.update(status='failed',error=str(e))
 return result
jobs=[(k,*v,dep) for k,v in sites.items() for dep in ['000_005','005_015','015_030','030_060','060_100']]
results=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:
 for r in ex.map(get,jobs):results.append(r);print(r['site'],r['depth'],r['status'],r.get('bytes',r.get('error')),flush=True)
(ROOT/'soil_downloads.json').write_text(json.dumps(results,indent=2))
