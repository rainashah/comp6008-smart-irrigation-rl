"""Inspect downloaded AWC subsets. Requires Pillow; no field calibration implied."""
from pathlib import Path
from PIL import Image
import json,math,hashlib
ROOT=Path(__file__).resolve().parent
results=[]
for r in json.loads((ROOT/'soil_downloads.json').read_text()):
 s=dict(r)
 if r['status']=='downloaded':
  p=ROOT/r['file'];im=Image.open(p);vals=list(im.getdata());nodata=float(im.tag_v2.get(42113,'65535'));good=[v for v in vals if v!=nodata and math.isfinite(v)]
  s.update(size=list(im.size),sample_count=len(vals),valid_count=len(good),nodata_count=len(vals)-len(good),min_awc_percent=min(good) if good else None,max_awc_percent=max(good) if good else None,mean_awc_percent=sum(good)/len(good) if good else None,geotransform=list(im.tag_v2.get(34264,[])),sha256=hashlib.sha256(p.read_bytes()).hexdigest())
 results.append(s)
(ROOT/'soil_audit.json').write_text(json.dumps({'scope':'Small WCS subsets around weather-station coordinates for access and numerical screening only. Output grid is service-generated; this is not a native-resolution field extraction. AWC values are model estimates, not measured field parameters. No field root depth, drainage, DUL/LL15 or confidence intervals have been finalised.','results':results},indent=2))
for r in results:print(r['site'],r['depth'],r.get('valid_count'),r.get('min_awc_percent'),r.get('max_awc_percent'))
