"""Recompute climate quality checks from unmodified SILO alldata downloads."""
from pathlib import Path
from datetime import date,datetime,timedelta
from collections import Counter
import re,json,hashlib,math,statistics
ROOT=Path(__file__).resolve().parent
START=date(2005,1,1); END=date(2025,12,31)
EXPECTED={START+timedelta(days=i) for i in range((END-START).days+1)}
COLS={'tmax_c':3,'tmax_source':4,'tmin_c':5,'tmin_source':6,'rain_mm':7,'rain_source':8,'radiation_mj_m2':11,'radiation_source':12,'vapour_pressure_hpa':13,'vapour_pressure_source':14,'eto_mm':17}
CODES={0:'Official station observation',13:'Deaccumulated using nearby station',15:'Deaccumulated using interpolated data',23:'Nearby station observation',25:'Interpolated daily observations',26:'Derived',35:'Anomaly interpolation',42:'Satellite radiation estimate',75:'Long-term daily average interpolation'}
def consecutive(rows,key):
 best=run=0
 for r in rows:
  run=run+1 if r[key]!=0 else 0;best=max(best,run)
 return best
results={}
for p in sorted((ROOT/'raw').glob('*_0*.txt')):
 rows=[];malformed=[]
 for lineno,line in enumerate(p.read_text().splitlines(),1):
  if not re.match(r'^\d{8}\s',line):continue
  a=line.split()
  if len(a)!=28:malformed.append(lineno);continue
  r={'date':datetime.strptime(a[0],'%Y%m%d').date()}
  for k,i in COLS.items():r[k]=int(a[i]) if k.endswith('source') else float(a[i])
  rows.append(r)
 days=[r['date'] for r in rows];n=len(rows)
 s={'rows':n,'first_date':str(min(days)),'last_date':str(max(days)), 'expected_rows':len(EXPECTED),'missing_dates':sorted(map(str,EXPECTED-set(days))),'out_of_range_dates':sorted(map(str,set(days)-EXPECTED)),'duplicate_dates':n-len(set(days)),'chronological':days==sorted(days),'malformed_line_numbers':malformed,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'source_counts':{},'official_observation_percent':{},'longest_nonobserved_run_days':{},'ranges':{},'checks':{}}
 for k in COLS:
  if k.endswith('source'):
   s['source_counts'][k]=dict(Counter(r[k] for r in rows));s['official_observation_percent'][k]=round(100*sum(r[k]==0 for r in rows)/n,4);s['longest_nonobserved_run_days'][k]=consecutive(rows,k)
  else:
   vals=[r[k] for r in rows];s['ranges'][k]={'min':min(vals),'max':max(vals),'mean':statistics.mean(vals)}
 s['checks']['nonfinite_values']=sum(not math.isfinite(r[k]) for r in rows for k in COLS)
 s['checks']['sentinel_values']=sum(r[k] in [-99.9,999,999.9,9999.9] for r in rows for k in COLS)
 s['checks']['tmin_exceeds_tmax']=sum(r['tmin_c']>r['tmax_c'] for r in rows)
 for k in ['rain_mm','eto_mm','radiation_mj_m2','vapour_pressure_hpa']:s['checks']['negative_'+k]=sum(r[k]<0 for r in rows)
 s['checks']['long_term_average_source_values']=sum(r[k]==75 for r in rows for k in COLS if k.endswith('source'))
 s['annual']=[]
 for year in range(2005,2026):
  rr=[r for r in rows if r['date'].year==year]
  s['annual'].append({'year':year,'days':len(rr),'rain_mm':round(sum(r['rain_mm'] for r in rr),1),'eto_mm':round(sum(r['eto_mm'] for r in rr),1),**{k+'_observed_pct':round(100*sum(r[k]==0 for r in rr)/len(rr),2) for k in ['rain_source','tmax_source','tmin_source']}})
 # These are calendar windows for comparing data coverage, not a validated planting schedule.
 s['seasonal_window_audit']={}
 for label,months in [('nov_mar',[11,12,1,2,3]),('apr_sep',[4,5,6,7,8,9])]:
  rr=[r for r in rows if r['date'].month in months]
  s['seasonal_window_audit'][label]={'days':len(rr),**{k+'_observed_pct':round(100*sum(r[k]==0 for r in rr)/len(rr),2) for k in ['rain_source','tmax_source','tmin_source']}}
 results[p.stem]=s
 (ROOT/(p.stem+'_daily.json')).write_text(json.dumps(rows,default=str))
(ROOT/'climate_audit.json').write_text(json.dumps({'period':['2005-01-01','2025-12-31'],'source_code_definitions':CODES,'results':results},indent=2))
for k,s in results.items():print(k,json.dumps({a:s[a] for a in ['rows','missing_dates','duplicate_dates','source_counts','official_observation_percent','checks','ranges','longest_nonobserved_run_days','seasonal_window_audit']},indent=2))
