"""Re-download the same SILO station period. Set SILO_EMAIL before running.
SILO requires a valid contact email. It is not stored in the output metadata.
"""
import os,urllib.request,urllib.parse
from pathlib import Path
ROOT=Path(__file__).resolve().parent
email=os.environ.get('SILO_EMAIL')
if not email:raise SystemExit('Set SILO_EMAIL to your authorised email address.')
(ROOT/'raw').mkdir(exist_ok=True)
for name,station in [('kyabram_080091','80091'),('kununurra_aero_002056','2056'),('kununurra_002038','2038')]:
 p=dict(station=station,start='20050101',finish='20251231',format='alldata',username=email)
 url='https://www.longpaddock.qld.gov.au/cgi-bin/silo/PatchedPointDataset.php?'+urllib.parse.urlencode(p)
 with urllib.request.urlopen(url,timeout=90) as r:data=r.read()
 if b'20050101' not in data or b'20251231' not in data:raise ValueError('Download missing expected boundary dates')
 (ROOT/'raw'/(name+'.txt')).write_bytes(data)
 print(name,len(data))
